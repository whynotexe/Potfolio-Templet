import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/portfolio/Navbar";
import { Hero } from "@/components/portfolio/Hero";
import { About } from "@/components/portfolio/About";
import { Skills } from "@/components/portfolio/Skills";
import { Projects } from "@/components/portfolio/Projects";
import { Contact } from "@/components/portfolio/Contact";
import { Footer } from "@/components/portfolio/Footer";
import { Toaster } from "@/components/ui/sonner";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Nadeem Jawed — Sudoexe | HTML & Python Developer" },
      { name: "description", content: "Portfolio of Nadeem Jawed (Sudoexe) — mastery in HTML & Python, enthusiast of everything new in tech." },
      { property: "og:title", content: "Nadeem Jawed — Sudoexe" },
      { property: "og:description", content: "HTML & Python developer · enthusiastic learner of modern tech." },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <main className="min-h-screen bg-background text-foreground antialiased">
      <Navbar />
      <Hero />
      <About />
      <Skills />
      <Projects />
      <Contact />
      <Footer />
      <Toaster />
    </main>
  );
}
