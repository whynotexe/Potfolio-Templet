import { motion } from "framer-motion";
import { ArrowUpRight, Github } from "lucide-react";
import { Section, SectionHeader } from "./Section";

const projects = [
  {
    title: "Static Web Foundations",
    desc: "Hand-crafted HTML5 templates exploring semantic structure, accessibility, and modern CSS layouts.",
    tags: ["HTML5", "CSS", "Responsive"],
    repo: "https://github.com/whynotexe",
    glyph: "01",
  },
  {
    title: "Python Utilities",
    desc: "A growing collection of Python scripts: automations, parsers, and small CLI tools that solve real friction.",
    tags: ["Python", "CLI", "Automation"],
    repo: "https://github.com/whynotexe",
    glyph: "02",
  },
  {
    title: "Learning Lab",
    desc: "Experiments while learning JavaScript, React, and APIs — a living sandbox documented commit by commit.",
    tags: ["JS", "React", "APIs"],
    repo: "https://github.com/whynotexe",
    glyph: "03",
  },
  {
    title: "Sudoexe Notes",
    desc: "Personal notes & micro-projects on everything new I touch — terminal, Linux, AI tools, and beyond.",
    tags: ["Notes", "Linux", "AI"],
    repo: "https://github.com/whynotexe",
    glyph: "04",
  },
];

export function Projects() {
  return (
    <Section id="projects">
      <SectionHeader index="03 / projects" title="Selected work." kicker="A snapshot of what I build and break while learning." />

      <div className="grid sm:grid-cols-2 gap-px bg-border border border-border">
        {projects.map((p, i) => (
          <motion.a
            key={p.title}
            href={p.repo}
            target="_blank"
            rel="noreferrer"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: i * 0.08 }}
            className="group relative bg-background hover:bg-foreground transition-colors duration-500 p-8 flex flex-col min-h-[340px]"
          >
            <div className="flex items-start justify-between mb-8">
              <div className="font-mono text-xs text-muted-foreground group-hover:text-background/60 transition-colors">
                {p.glyph} / project
              </div>
              <ArrowUpRight className="w-5 h-5 text-muted-foreground group-hover:text-background group-hover:rotate-45 transition-all duration-300" />
            </div>

            <div className="flex-1 flex items-center justify-center">
              <div className="font-display text-7xl font-bold text-stroke group-hover:[-webkit-text-stroke:1px_rgba(0,0,0,0.7)] transition-all">
                {p.glyph}
              </div>
            </div>

            <div className="mt-8">
              <h3 className="font-display text-2xl font-bold mb-2 text-foreground group-hover:text-background transition-colors">
                {p.title}
              </h3>
              <p className="text-sm text-muted-foreground group-hover:text-background/70 transition-colors mb-4">
                {p.desc}
              </p>
              <div className="flex flex-wrap gap-2">
                {p.tags.map((t) => (
                  <span
                    key={t}
                    className="font-mono text-xs px-2 py-1 border border-border text-muted-foreground group-hover:border-background/40 group-hover:text-background/80 transition-colors"
                  >
                    {t}
                  </span>
                ))}
              </div>
            </div>
          </motion.a>
        ))}
      </div>

      <div className="mt-10 flex justify-center">
        <a
          href="https://github.com/whynotexe"
          target="_blank"
          rel="noreferrer"
          className="group inline-flex items-center gap-2 font-mono text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          <Github className="w-4 h-4" />
          See more on github.com/whynotexe
          <ArrowUpRight className="w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
        </a>
      </div>
    </Section>
  );
}