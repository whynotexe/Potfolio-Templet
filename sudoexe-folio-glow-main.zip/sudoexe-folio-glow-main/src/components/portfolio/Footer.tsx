export function Footer() {
  return (
    <footer className="border-t border-border">
      <div className="max-w-7xl mx-auto px-6 py-10 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="font-mono text-xs text-muted-foreground">
          © {new Date().getFullYear()} Nadeem Jawed · sudoexe
        </div>
        <div className="flex flex-col items-center md:items-end gap-1">
          <div className="font-mono text-xs text-muted-foreground">
            built with <span className="text-foreground">{"<html>"}</span> &amp; <span className="text-foreground">python</span>
          </div>
          <div className="font-mono text-[10px] text-muted-foreground/50 select-none">
            made by Syed_exe
          </div>
        </div>
      </div>
    </footer>
  );
}