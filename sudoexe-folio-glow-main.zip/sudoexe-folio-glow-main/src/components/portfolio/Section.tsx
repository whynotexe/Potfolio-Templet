import { motion } from "framer-motion";
import type { ReactNode } from "react";

export function SectionHeader({ index, title, kicker }: { index: string; title: string; kicker?: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 0.6 }}
      className="mb-16 flex items-end justify-between gap-8 border-b border-border pb-6"
    >
      <div>
        <div className="font-mono text-xs text-muted-foreground mb-3">{index}</div>
        <h2 className="font-display text-4xl sm:text-5xl md:text-6xl font-bold tracking-tighter">{title}</h2>
      </div>
      {kicker && (
        <div className="hidden md:block font-mono text-xs text-muted-foreground max-w-xs text-right">
          {kicker}
        </div>
      )}
    </motion.div>
  );
}

export function Section({ id, children, className = "" }: { id?: string; children: ReactNode; className?: string }) {
  return (
    <section id={id} className={`relative max-w-7xl mx-auto px-6 py-28 ${className}`}>
      {children}
    </section>
  );
}