import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import { ArrowDown, ArrowUpRight } from "lucide-react";
import avatarAsset from "@/assets/avatar.jpg.asset.json";

const phrases = [
  "Master in HTML & Python",
  "Cybersecurity Expert",
  "Exploring & Learning Everything Else",
  "Aka Sudoexe",
];

function useTyping() {
  const [text, setText] = useState("");
  const [i, setI] = useState(0);
  const [del, setDel] = useState(false);

  useEffect(() => {
    const current = phrases[i % phrases.length];
    const speed = del ? 40 : 80;
    const t = setTimeout(() => {
      if (!del) {
        const next = current.slice(0, text.length + 1);
        setText(next);
        if (next === current) setTimeout(() => setDel(true), 1400);
      } else {
        const next = current.slice(0, text.length - 1);
        setText(next);
        if (next === "") {
          setDel(false);
          setI((v) => v + 1);
        }
      }
    }, speed);
    return () => clearTimeout(t);
  }, [text, del, i]);

  return text;
}

export function Hero() {
  const typed = useTyping();

  return (
    <section id="home" className="relative min-h-screen flex items-center overflow-hidden pt-24 pb-16">
      <div className="absolute inset-0 grain opacity-40 pointer-events-none" />
      <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.04)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.04)_1px,transparent_1px)] bg-[size:64px_64px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_60%,transparent_100%)]" />

      <div className="relative max-w-7xl mx-auto px-6 w-full">
        <motion.div
          initial={{ opacity: 0, scale: 0.8, rotate: -6 }}
          animate={{ opacity: 1, scale: 1, rotate: 0 }}
          transition={{ delay: 0.3, duration: 0.8 }}
          className="absolute top-0 right-6 sm:right-10 w-32 h-32 sm:w-44 sm:h-44 md:w-56 md:h-56 rounded-full overflow-hidden border border-foreground/40 grayscale shadow-[0_0_60px_rgba(255,255,255,0.08)]"
        >
          <img src={avatarAsset.url} alt="Nadeem Jawed" className="w-full h-full object-cover" />
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.6 }}
          className="font-mono text-sm text-muted-foreground mb-6"
        >
          <span className="text-foreground">$</span> whoami
        </motion.p>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.8 }}
          className="font-display text-5xl sm:text-7xl md:text-8xl font-bold tracking-tighter leading-[0.95]"
        >
          Hi, I'm <br className="sm:hidden" />
          <span className="text-stroke">Nadeem</span> Jawed.
        </motion.h1>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.9, duration: 0.6 }}
          className="mt-8 font-mono text-base sm:text-xl text-muted-foreground min-h-[2em]"
        >
          <span className="text-foreground">&gt; </span>
          {typed}
          <span className="blink text-foreground">▍</span>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2, duration: 0.6 }}
          className="mt-12 flex flex-wrap gap-4"
        >
          <a
            href="#projects"
            className="group inline-flex items-center gap-2 px-6 py-3 bg-foreground text-background font-medium hover:bg-background hover:text-foreground border border-foreground transition-all duration-300"
          >
            View My Work
            <ArrowDown className="w-4 h-4 group-hover:translate-y-1 transition-transform" />
          </a>
          <a
            href="#contact"
            className="group inline-flex items-center gap-2 px-6 py-3 border border-foreground text-foreground hover:bg-foreground hover:text-background transition-all duration-300"
          >
            Connect With Me
            <ArrowUpRight className="w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
          </a>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.6, duration: 0.6 }}
          className="mt-20 flex items-center gap-8 font-mono text-xs text-muted-foreground"
        >
          <div>
            <div className="text-foreground text-2xl font-display font-bold">∞</div>
            <div className="mt-1">curiosity</div>
          </div>
          <div className="h-10 w-px bg-border" />
          <div>
            <div className="text-foreground text-2xl font-display font-bold">02</div>
            <div className="mt-1">core stacks</div>
          </div>
          <div className="h-10 w-px bg-border" />
          <div>
            <div className="text-foreground text-2xl font-display font-bold">∀</div>
            <div className="mt-1">always learning</div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}