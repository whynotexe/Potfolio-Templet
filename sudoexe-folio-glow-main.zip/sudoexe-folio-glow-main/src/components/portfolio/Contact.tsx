import { motion } from "framer-motion";
import { useState } from "react";
import { Github, Linkedin, Twitter, Mail, Send } from "lucide-react";
import { Section, SectionHeader } from "./Section";
import { toast } from "sonner";

const socials = [
  { Icon: Mail, href: "mailto:exeop447@gmail.com", label: "exeop447@gmail.com" },
  { Icon: Twitter, href: "https://x.com/whynotex3", label: "X / Twitter" },
  { Icon: Github, href: "https://github.com/whynotexe", label: "GitHub" },
  { Icon: Linkedin, href: "https://www.linkedin.com/in/mr-nadeem-jawed-a71402407/", label: "LinkedIn" },
];

export function Contact() {
  const [sending, setSending] = useState(false);

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSending(true);
    const form = e.currentTarget;
    const data = new FormData(form);
    const subject = encodeURIComponent(`Portfolio message from ${data.get("name")}`);
    const body = encodeURIComponent(`${data.get("message")}\n\n— ${data.get("name")} (${data.get("email")})`);
    setTimeout(() => {
      window.location.href = `mailto:exeop447@gmail.com?subject=${subject}&body=${body}`;
      toast.success("Opening your mail client…");
      form.reset();
      setSending(false);
    }, 400);
  }

  return (
    <Section id="contact">
      <SectionHeader index="04 / contact" title="Let's build." kicker="Got an idea, a project, or just want to say hi? My inbox is open." />

      <div className="grid md:grid-cols-12 gap-12">
        <motion.form
          onSubmit={handleSubmit}
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="md:col-span-7 space-y-6"
        >
          {[
            { name: "name", label: "Your name", type: "text" },
            { name: "email", label: "Your email", type: "email" },
          ].map((f) => (
            <div key={f.name} className="group">
              <label className="block font-mono text-xs text-muted-foreground mb-2">
                {f.label}
              </label>
              <input
                required
                type={f.type}
                name={f.name}
                className="w-full bg-transparent border-b border-border focus:border-foreground outline-none py-3 text-lg transition-colors"
              />
            </div>
          ))}

          <div>
            <label className="block font-mono text-xs text-muted-foreground mb-2">Message</label>
            <textarea
              required
              name="message"
              rows={4}
              className="w-full bg-transparent border-b border-border focus:border-foreground outline-none py-3 text-lg transition-colors resize-none"
            />
          </div>

          <button
            type="submit"
            disabled={sending}
            className="group inline-flex items-center gap-2 px-6 py-3 bg-foreground text-background font-medium hover:bg-background hover:text-foreground border border-foreground transition-all duration-300 disabled:opacity-60"
          >
            {sending ? "Sending…" : "Send Message"}
            <Send className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </motion.form>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.15 }}
          className="md:col-span-5 space-y-8"
        >
          <div>
            <div className="font-mono text-xs text-muted-foreground mb-3">// elsewhere</div>
            <ul className="space-y-1">
              {socials.map(({ Icon, href, label }) => (
                <li key={label}>
                  <a
                    href={href}
                    target={href.startsWith("mailto:") ? undefined : "_blank"}
                    rel="noreferrer"
                    className="group flex items-center justify-between border-b border-border py-4 hover:pl-2 transition-all duration-300"
                  >
                    <span className="flex items-center gap-3">
                      <Icon className="w-5 h-5 group-hover:scale-110 transition-transform" />
                      <span className="font-display text-lg">{label}</span>
                    </span>
                    <span className="font-mono text-xs text-muted-foreground group-hover:text-foreground transition-colors">
                      →
                    </span>
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </motion.div>
      </div>
    </Section>
  );
}