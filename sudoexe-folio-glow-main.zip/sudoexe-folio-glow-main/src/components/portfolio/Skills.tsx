import { motion } from "framer-motion";
import { Section, SectionHeader } from "./Section";

const learning = [
  "JavaScript", "TypeScript", "React", "Node.js", "Next.js", "Tailwind CSS",
  "Django", "FastAPI", "PostgreSQL", "Docker", "Git", "Linux",
  "AI / ML", "REST APIs", "GraphQL", "Cloud",
];

export function Skills() {
  return (
    <Section id="skills">
      <SectionHeader index="02 / skills" title="What I work with." kicker="Two stacks mastered. The rest, on the way." />

      <div className="grid md:grid-cols-2 gap-6 mb-16">
        {[
          { name: "HTML5", desc: "Semantic, accessible, pixel-precise markup.", code: "<html lang=\"en\">" },
          { name: "Python", desc: "Clean scripts, automations, backend logic.", code: "def build(): ..." },
        ].map((s, i) => (
          <motion.div
            key={s.name}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: i * 0.1 }}
            className="group relative border border-border p-8 bg-card hover:bg-foreground hover:text-background transition-all duration-500"
          >
            <div className="font-mono text-xs opacity-60 mb-4">// core mastery</div>
            <div className="font-display text-5xl font-bold tracking-tighter mb-3">{s.name}</div>
            <p className="text-muted-foreground group-hover:text-background/70 transition-colors mb-6">{s.desc}</p>
            <code className="font-mono text-sm opacity-70">{s.code}</code>
            <div className="absolute top-6 right-6 font-mono text-xs opacity-40">
              0{i + 1}
            </div>
          </motion.div>
        ))}
      </div>

      <div className="font-mono text-xs text-muted-foreground mb-6">// continuous learning</div>
      <div className="relative overflow-hidden border-y border-border py-6">
        <div className="marquee flex gap-12 whitespace-nowrap">
          {[...learning, ...learning].map((t, i) => (
            <span key={i} className="font-display text-3xl font-bold tracking-tight text-stroke hover:text-foreground transition-colors">
              {t} <span className="text-muted-foreground mx-4">/</span>
            </span>
          ))}
        </div>
      </div>
    </Section>
  );
}