import { motion } from "framer-motion";
import { Section, SectionHeader } from "./Section";

export function About() {
  return (
    <Section id="about">
      <SectionHeader index="01 / about" title="About me." kicker="Code is the language. Curiosity is the compiler." />
      <div className="grid md:grid-cols-12 gap-12 items-start">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="md:col-span-7 space-y-6 text-lg leading-relaxed text-muted-foreground"
        >
          <p>
            I'm <span className="text-foreground font-medium">Nadeem Jawed</span> — also known online as
            <span className="font-mono text-foreground"> sudoexe</span>. I build on the web with an absolute
            mastery of <span className="text-foreground">HTML</span> and a deep, scripted love for
            <span className="text-foreground"> Python</span>.
          </p>
          <p>
            My approach is simple: keep the fundamentals razor-sharp, then chase every new technology that
            sparks curiosity. From clean semantic markup to elegant Python automations, I care about craft —
            the kind that reads well, runs fast, and ages gracefully.
          </p>
          <p>
            Right now I'm exploring the rest of the modern stack — one experiment, one repo, one commit at a time.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.15 }}
          className="md:col-span-5 border border-border p-8 bg-card"
        >
          <div className="font-mono text-xs text-muted-foreground mb-4">~/about.json</div>
          <pre className="font-mono text-sm leading-relaxed overflow-x-auto">
{`{
  "name":    "Nadeem Jawed",
  "alias":   "sudoexe",
  "github":  "whynotexe",
  "core":    ["HTML5", "Python"],
  "mode":    "always learning",
  "status":  "open to collab"
}`}
          </pre>
        </motion.div>
      </div>
    </Section>
  );
}